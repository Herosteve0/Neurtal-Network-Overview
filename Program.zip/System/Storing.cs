namespace Neurtal_Network_Overview.System {
    public class NetworkFile(string filepath) {
        private string FilePath { get; } = Path.GetFullPath("../../../"  + filepath);

        public void Save(NeuralNetwork network) {
            using BinaryWriter writer = new BinaryWriter(File.Open(FilePath, FileMode.Create));

            writer.Write("NeuralNetworkEduProject");
            
            writer.Write(network.LayerAmount);
            for (int i = 0; i < network.LayerAmount; i++) {
                writer.Write(network.LayerLength[i]);
            }

            IBackend backend = network.Backend;
            
            for (int i = 1; i < network.LayerAmount; i++) {
                Layer layer = (Layer)network[i];

                foreach (float v in backend.Read(layer.Weights)) { writer.Write(v); }
                foreach (float v in backend.Read(layer.Bias)) { writer.Write(v); }
            }
        }

        public NeuralNetwork Load(IBackend backend) {
            if (!Path.Exists(FilePath)) {
                return null;
            }

            using BinaryReader reader = new BinaryReader(File.OpenRead(FilePath));

            string header = reader.ReadString();

            int layerAmount = reader.ReadInt32();
            int[] layers = new int[layerAmount];
            for (int i = 0; i < layerAmount; i++) {
                layers[i] = reader.ReadInt32();
            }
            
            float[][] weights = new float[layerAmount][];
            float[][] bias = new float[layerAmount][];

            for (int i = 1; i < layerAmount; i++) {
                
                weights[i] = new float[layers[i] * layers[i - 1]];
                for (int row = 0; row < layers[i]; row++) {
                    int rowOffset = row * layers[i - 1];
                    for (int col = 0; col < layers[i - 1]; col++) {
                        weights[i][rowOffset + col] = reader.ReadSingle();
                    }
                }

                bias[i] = new float[layers[i]];
                for (int row = 0; row < layers[i]; row++) {
                    bias[i][row] = reader.ReadSingle();
                }
            }
            
            return new NeuralNetwork(layers, backend, weights, bias);
        }
    }
}