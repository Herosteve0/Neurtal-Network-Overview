
using Neurtal_Network_Overview.Data;

namespace Neurtal_Network_Overview.System {
    public class Tester : NetworkScanner {
        private const int DelayTicks = 2500;
        
        public Tester(NeuralNetwork network, int batchSize, bool isSilent = false) : base("Tester", network, batchSize, DelayTicks, isSilent) { }
        
        private List<DataGuess<float>> _mistakes;
        public int TestingAccuracy { get; private set; }

        public async Task<int> Test(DataBatch<float> dataBatch, bool showMistakes = false) {
            _mistakes = [];
            
            await Scan(dataBatch);
            
            int testingAccuracy = dataBatch.Size - _mistakes.Count;
            Console.WriteLine($"Testing completed with {(double)testingAccuracy / dataBatch.Size * 100}% accuracy. [{testingAccuracy}/{dataBatch.Size}]");
            if (showMistakes) {
                ProgramExecutor.DrawImages(_mistakes.ToArray());
            }

            return testingAccuracy;
        }

        protected override void Process(DataBatch<float> testingData) {
            if (Backend is CpuBackend && ProgramExecutor.MultiThread) {
                ExecuteMultiThread(testingData);
            }
            else {
                Execute(testingData);
            }
        }

        private void Execute(DataBatch<float> dataBatch) {
            VirtualNetwork network = new VirtualNetwork(Network);

            foreach (DataSample<float> testingData in dataBatch.Data) {
                int guess = TestingCalculations(testingData, network);
                if (guess == testingData.Label) continue;
                
                _mistakes.Add(new DataGuess<float>(testingData, guess));
            }
            
            network.Dispose();
        }

        private void ExecuteMultiThread(DataBatch<float> dataBatch) {
            object lockObj = new object();

            Parallel.For(
                0L, dataBatch.Size,

                () => new LocalThread(Network),
                (i, state, local) => {
                    DataSample<float> data = dataBatch.Data[i];
                    int guess = TestingCalculations(data, local.VirtualNetwork);

                    if (guess != data.Label) {
                        local.Wrongs.Add(new DataGuess<float>(data, guess));
                    }

                    return local;
                },

                local => {
                    lock (lockObj) {
                        _mistakes.AddRange(local.Wrongs);
                    }
                    
                    local.VirtualNetwork.Dispose();
                }

            );
        }
        private class LocalThread(NeuralNetwork network) {
            public readonly VirtualNetwork VirtualNetwork = new(network);
            public readonly List<DataGuess<float>> Wrongs = [];
        }

        private int TestingCalculations(DataSample<float> testingData, VirtualNetwork network) {
            ITensor result = Network.Calculate(testingData, network);
            return Backend.MaxVectorIndex(result);
        }
    }
}