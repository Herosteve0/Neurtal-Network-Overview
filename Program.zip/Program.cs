﻿using System.Drawing;
using Neurtal_Network_Overview.Data;
using Neurtal_Network_Overview.System;


IBackend backend = new SimdBackend();
Random random = new Random(5000);

NeuralNetwork network;
Trainer trainer;
Tester tester;

ProgramExecutor runner = new ProgramExecutor(
    true,
    false, 
    5000
    );
NetworkFile storer = new NetworkFile("save.nn");

DataBatch<float> trainingData = new DataBatch<float>(MnistDatabase.LoadAllTrainingData());
DataBatch<float> testingData = new DataBatch<float>(MnistDatabase.LoadAllTestingData());

network = storer.Load(backend);
int oldAccuracy = 0;
if (network != null) {
    tester = new Tester(network, 1000);
    await tester.Test(testingData);
    oldAccuracy = tester.TestingAccuracy;
}

network = new NeuralNetwork([784, 512, 512, 512, 512, 10], backend, random);
trainer = new Trainer(
    network,
    1000,
    new TrainerLearningInfo(0.85f, 0.75f, 500),
    false
    );
tester = new Tester(network, 1000);

await trainer.Train(trainingData.GetSmallBatch(0, 10000), 1);
int testingAccuracy = await tester.Test(testingData, true);

int deltaAccuracy = testingAccuracy - oldAccuracy;
Console.WriteLine($"Accuracy changed by {deltaAccuracy}");
if (deltaAccuracy > 0) {
    Console.WriteLine($"Neural Network saved.");
    storer.Save(network);
}

public class ProgramExecutor {
    public static Random Random { get; private set; }
    private readonly bool _disableMessages;
    public static bool MultiThread;

    public NeuralNetwork Network;
    public Trainer Trainer;
    public Tester Tester;

    public ProgramExecutor(bool multiThread, bool disableMessages, int randomSeed) {
        MultiThread = multiThread;
        
        _disableMessages = disableMessages;
        Random = new Random(randomSeed);
    }

    public void CreateNetwork(int[] layers, IBackend backend) {
    }

    /**
     * Returns a random integer [min, max].
     * <param name="min"> Lowest inclusive integer. </param>
     * <param name="max"> Highest inclusive integer. </param>
     */
    public static int GetRandomInt(int min, int max) {
        return Random.Next(min, max + 1);
    }

    public static void DrawImages(DataGuess<float>[] wrongs){
        const string filepath = @".\WrongGuesses";

        if (Path.Exists(filepath)) Directory.Delete(filepath, true);
        Directory.CreateDirectory(filepath);

        for (int i = 0; i < wrongs.Length; i++) {
            DataSample<float> data = wrongs[i].Data;
            int guess = wrongs[i].Guess;
            
            CreateImage(data, $"{filepath}/{i}. {guess} instead of {data.Label}.png");
        }
    }

    private static void CreateImage(DataSample<float> data, string filepath) {
        const int width = 28;
        const int height = 28;

        Bitmap image = new Bitmap(width, height);

        int i = 0;
        for (int y = 0; y < height; y++) { 
            for (int x = 0; x < width; x++) {
                byte value = (byte)(Math.Clamp((int)(data.Values[i++] * 255f), 0, 255));
                image.SetPixel(x, y, Color.FromArgb(value, value, value));
            }
        }

        image.Save(filepath);
    }
}