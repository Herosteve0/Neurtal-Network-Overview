using System.Runtime.InteropServices.Swift;
using Neurtal_Network_Overview.Data;

namespace Neurtal_Network_Overview.System {
    public class NeuralNetwork {
        
        private BaseLayer[] Layers { get; }
        
        public IBackend Backend { get; }
        
        public NeuralNetwork(int[] layers, IBackend backend, Random random) {
            Backend = backend;
            LayerAmount = layers.Length;
            LayerLength = layers.ToArray();
            
            Layers = new BaseLayer[LayerAmount];
            for (int i = 0; i < LayerAmount; i++) {
                int length = layers[i];
                Layers[i] = i == LayerAmount - 1
                    ? new OutputLayer(length, backend, Layers[i - 1], random)
                    : i == 0
                        ? new InputLayer(length, backend)
                        : new Layer(length, backend, Layers[i - 1], random);
            }
        }
        public NeuralNetwork(int[] layers, IBackend backend, float[][] weights, float[][] bias) {
            Backend = backend;
            LayerAmount = layers.Length;
            LayerLength = layers.ToArray();
            
            Layers = new BaseLayer[LayerAmount];
            for (int i = 0; i < LayerAmount; i++) {
                int length = layers[i];
                Layers[i] = i == LayerAmount - 1
                    ? new OutputLayer(length, backend, Layers[i - 1], bias[i], weights[i])
                    : i == 0
                        ? new InputLayer(length, backend)
                        : new Layer(length, backend, Layers[i - 1], bias[i], weights[i]);
            }
        }
        
        public BaseLayer this[int index] => Layers[index];


        public int LayerAmount { get; }
        public int[] LayerLength { get; }

        public ITensor QuickCalculate(DataSample<float> input) {
            VirtualNetwork network = new VirtualNetwork(this);
            ITensor result = Calculate(input, network);
            network.Dispose();
            return result;
        }
        public ITensor Calculate(DataSample<float> input, VirtualNetwork network) {
            network.Load(input);
            for (int i = 0; i < LayerAmount; i++) {
                network.Forward(i, Layers[i]);
            }

            return network.GetActivation(LayerAmount - 1);
        }
    }

    public class VirtualNetwork : IDisposable {
        private readonly ITensor _input;
        private readonly ITensor[] _values;
        private readonly ITensor[] _activations;
        
        private readonly ITensor[] _delta;
        private readonly ITensor[] _weightDelta;
        private readonly ITensor[] _biasDelta;

        public readonly IBackend Backend;
        public readonly int Length;
        public float Loss;
        
        public VirtualNetwork(NeuralNetwork network) : this(network.LayerLength.ToArray(), network.Backend) { }
        public VirtualNetwork(int[] layers, IBackend backend) {
            Length = layers.Length;
            Backend = backend;
            
            _values = new ITensor[Length - 1];
            _activations = new ITensor[Length];
            
            _delta = new ITensor[Length - 1];
            _weightDelta = new ITensor[Length - 1];
            _biasDelta = new ITensor[Length - 1];
            
            
            _input = Backend.CreateTensor(layers[0]);
            
            for (int i = 0; i < Length; i++) {
                _activations[i] = Backend.CreateTensor(layers[i]);

                if (i == Length - 1) continue;
                
                _values[i] = Backend.CreateTensor(layers[i + 1]);

                _delta[i] = Backend.CreateTensor(layers[i + 1]);
                _weightDelta[i] = Backend.CreateTensor(layers[i + 1], layers[i]);
                _biasDelta[i] = Backend.CreateTensor(layers[i + 1]);
            }
        }
        
        public ITensor GetActivation(int index) => _activations[index];

        public void Load(DataSample<float> input) {
            Backend.Set(_input, input.Values);
        }

        public void Forward(int index, BaseLayer layer) {
            // Layer 0 has no parameters, so index is shifted by -1
            int l = index - 1;

            if (index == 0) {
                layer.Forward(_input, null, _activations[index]);
            } else {
                layer.Forward(_activations[index - 1], _values[l], _activations[index]);
            }
        }

        public void Backward(int index, BaseLayer layer, ITensor correctValues) {
            // Layer 0 has no parameters, so index is shifted by -1
            int l = index - 1;
            
            if (index == Length - 1) {
                layer.Backward(_activations[index], correctValues, _delta[l]);
            } else {
                layer.Backward(_values[l], _delta[l + 1] , _delta[l]);
            }
            
            layer.BackPropagation(_delta[l], _activations[index - 1], _weightDelta[l], _biasDelta[l]);
        }

        public void Adjust(int index, BaseLayer layer, float scale) {
            // Layer 0 has no parameters, so index is shifted by -1
            int l = index - 1;
            
            layer.Adjust(_weightDelta[l], _biasDelta[l], scale);
        }

        public void Dispose() {
            _input.Dispose();
            foreach (ITensor tensor in _values) {
                tensor.Dispose();
            }
            foreach (ITensor tensor in _activations) {
                tensor.Dispose();
            }
            foreach (ITensor tensor in _delta) {
                tensor.Dispose();
            }
            foreach (ITensor tensor in _weightDelta) {
                tensor.Dispose();
            }
            foreach (ITensor tensor in _biasDelta) {
                tensor.Dispose();
            }
        }
    }
}