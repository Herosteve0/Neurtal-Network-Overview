using System.Numerics;
using System.Runtime.InteropServices;
using Neurtal_Network_Overview.Data;


namespace Neurtal_Network_Overview.System {
    public class TrainerLearningInfo {
        public TrainerLearningInfo(float learningRate) {
            BaseLearningRate = learningRate;
            ResetLearningRate();

            _hasDecay = false;
        }
        public TrainerLearningInfo(float learningRate, float decayMultiplier, int decayPatience) : this(learningRate) {
            _hasDecay = true;
            
            _decayMultiplier = decayMultiplier;
            _decayPatience = decayPatience;
        }

        private float BaseLearningRate { get; }
        public float LearningRate { get; private set; }

        private readonly bool _hasDecay;
        private readonly float _decayMultiplier;
        private readonly float _decayPatience;

        private int _patienceCounter = 0;
        private float _minLoss = float.PositiveInfinity;

        public static implicit operator float(TrainerLearningInfo info) {
            if (info == null) return 0;
            return info.LearningRate;
        }

        public bool HasDecayed => LearningRate == 0f;
        
        public void ResetLearningRate() {
            LearningRate = BaseLearningRate;
        }
        
        public void CheckLoss(float loss) {
            if (!_hasDecay) return;
            
            if (loss < _minLoss) {
                _minLoss = loss;
                _patienceCounter = 0;
                return;
            }
            
            _patienceCounter++;
            if (_patienceCounter <= _decayPatience) return;
            
            _patienceCounter = 0;
            ApplyDecay();
        }

        public void ApplyDecay() {
            LearningRate *= _decayMultiplier;
        }
    }
    
    public class Trainer : NetworkScanner {
        
        private const int DelayTicks = 50;
        
        public Trainer(NeuralNetwork network, int batchSize, TrainerLearningInfo learningInfo, bool isSilent = false) : base("Trainer", network, batchSize, DelayTicks, isSilent) {
            LearningRate = learningInfo;
        }

        private TrainerLearningInfo LearningRate { get; }
        
        private List<float> _lossMemory;

        public async Task Train(DataBatch<float> dataBatch, int repeats) {
            _lossMemory = [];
            await Scan(dataBatch, true, repeats);
        }

        protected override void BreathFunction() {
            Console.WriteLine($"Training Loss: {_lossMemory.Average()}");
            _lossMemory.Clear();
        }

        protected override void Process(DataBatch<float> trainingData) {
            float scale = LearningRate / trainingData.Size;

            float averageLoss = Backend is CpuBackend && ProgramExecutor.MultiThread
                ? ExecuteMultiThread(trainingData, scale)
                : Execute(trainingData, scale);

            averageLoss /= trainingData.Size;
            LearningRate.CheckLoss(averageLoss);

            _lossMemory.Add(averageLoss);
        }

        private float Execute(DataBatch<float> dataBatch, float scale) {
            VirtualNetwork network = new VirtualNetwork(Network);

            float totalLoss = dataBatch.Data.Sum(
                trainingData => TrainVirtualNetwork(network, trainingData)
                );

            for (int i = 1; i < Network.LayerAmount; i++) {
                network.Adjust(i, Network[i], scale);
            }

            network.Dispose();
            return totalLoss;
        }

        private float ExecuteMultiThread(DataBatch<float> dataBatch, float scale) {
            float totalLoss = 0f;
            
            object lockObj = new object();
            Parallel.For(0L, dataBatch.Size, () => new VirtualNetwork(Network), (i, state, local) => {
                DataSample<float> data = dataBatch[(int)i];

                local.Loss += TrainVirtualNetwork(local, data);

                return local;
            }, local => {
                lock (lockObj) {
                    totalLoss += local.Loss;
                    for (int i = 1; i < Network.LayerAmount; i++) {
                        local.Adjust(i, Network[i], scale);
                    }
                    local.Dispose();
                }
            });
            
            return totalLoss;
        }

        private float TrainVirtualNetwork(VirtualNetwork network, DataSample<float> trainingData) {
            ITensor output = Network.Calculate(trainingData, network);
            // all layers of the network have the values we want (inupt, value, activation)

            int length = Network.LayerAmount - 1;

            ITensor expectedOutput = Backend.CreateTensor(trainingData.LabelArray(Network.LayerLength[length], 1), Network.LayerLength[length]);
            float loss = Backend.Loss(output, trainingData.Label);

            for (int i = length; i > 0; i--) {
                network.Backward(i, Network[i], expectedOutput);
            }

            return loss;
        }
    }
}